package com.airlines_app002;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlinesApp002ApplicationTests {

	@Test
	void contextLoads() {
	}

}
