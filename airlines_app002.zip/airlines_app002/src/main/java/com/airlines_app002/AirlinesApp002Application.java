package com.airlines_app002;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlinesApp002Application {

	public static void main(String[] args) {
		SpringApplication.run(AirlinesApp002Application.class, args);
	}

}
